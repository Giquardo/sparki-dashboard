"""
Buildings REST API.

Three endpoints:
  GET /api/buildings                    → list buildings
  GET /api/buildings/{id}/current       → latest measurement values
  GET /api/buildings/{id}/history       → time-series data

⚠️ NOTE: These routes are authenticated (require a valid Keycloak JWT),
but currently return data for ALL buildings regardless of the user's
role. The `buildings_visible_to(user)` permission filter is added in
Step 2.5 of Phase 2. Until then, this is dev-only.
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.auth.dependencies import get_current_user
from app.auth.schemas import CurrentUser
from app.buildings.models import Building
from app.buildings.schemas import (
    BuildingCurrent,
    BuildingHistory,
    BuildingOut,
)
from app.buildings.service import get_history, get_latest_for_building
from app.database import get_session

logger = logging.getLogger("sparki.buildings.routes")

router = APIRouter(prefix="/api/buildings", tags=["buildings"])


# ─── List ────────────────────────────────────────────────────────────
@router.get(
    "",
    response_model=list[BuildingOut],
    summary="List buildings",
    description=(
        "Returns all active buildings. In Phase 2.5 this will be filtered "
        "by `buildings_visible_to(current_user)`."
    ),
)
async def list_buildings(
    user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_session)],
) -> list[Building]:
    """Return every active building.

    SECURITY NOTE: Permission filtering is not yet applied — every
    authenticated user sees every building. To be hardened in Step 2.5.
    """
    stmt = select(Building).where(Building.active.is_(True)).order_by(Building.name)
    result = await db.execute(stmt)
    return list(result.scalars().all())


# ─── Current snapshot ────────────────────────────────────────────────
@router.get(
    "/{building_id}/current",
    response_model=BuildingCurrent,
    summary="Latest measurement values",
    description=(
        "Returns the most recent value of each tracked field for one "
        "building. If a field hasn't been reported in the last 10 "
        "minutes, its value will be `null`."
    ),
)
async def get_current(
    building_id: uuid.UUID,
    user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_session)],
) -> BuildingCurrent:
    """Return the latest snapshot for one building.

    Two-step lookup:
      1. Verify the building exists in Postgres (404 if not)
      2. Pull latest values from InfluxDB
    """
    await _ensure_building_exists(db, building_id)
    return await get_latest_for_building(building_id)


# ─── History ─────────────────────────────────────────────────────────
@router.get(
    "/{building_id}/history",
    response_model=BuildingHistory,
    summary="Time-series history",
    description=(
        "Returns aggregated time-series data for a building. Defaults "
        "to last 24 hours at 60-second resolution. Use `start`, `end`, "
        "and `interval_seconds` to customize the window."
    ),
)
async def get_building_history(
    building_id: uuid.UUID,
    user: Annotated[CurrentUser, Depends(get_current_user)],
    db: Annotated[AsyncSession, Depends(get_session)],
    start: Annotated[
        datetime | None,
        Query(description="UTC start time. Defaults to 24h ago."),
    ] = None,
    end: Annotated[
        datetime | None,
        Query(description="UTC end time. Defaults to now."),
    ] = None,
    interval_seconds: Annotated[
        int,
        Query(
            ge=10,
            le=3600,
            description="Aggregation window in seconds (10–3600).",
        ),
    ] = 60,
) -> BuildingHistory:
    """Return a time-series for a building.

    Guards against silly queries:
      - end must be after start
      - the requested range can't exceed 30 days (protects InfluxDB)
    """
    await _ensure_building_exists(db, building_id)

    if start is not None and end is not None:
        if end <= start:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="`end` must be after `start`.",
            )
        if (end - start) > timedelta(days=30):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Requested range exceeds the 30-day maximum.",
            )

    # Normalize tz-naive datetimes to UTC; FastAPI parses ISO strings
    # but they can come in without timezone info.
    if start is not None and start.tzinfo is None:
        start = start.replace(tzinfo=timezone.utc)
    if end is not None and end.tzinfo is None:
        end = end.replace(tzinfo=timezone.utc)

    return await get_history(
        building_id,
        start=start,
        end=end,
        interval_seconds=interval_seconds,
    )


# ─── Helpers ─────────────────────────────────────────────────────────
async def _ensure_building_exists(
    db: AsyncSession,
    building_id: uuid.UUID,
) -> Building:
    """Look up a building by ID, raising 404 if not found.

    Also returns the row so callers that want it (e.g. for future
    permission checks) don't need a second query.
    """
    result = await db.execute(select(Building).where(Building.id == building_id))
    building = result.scalar_one_or_none()
    if building is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Building {building_id} not found",
        )
    return building
